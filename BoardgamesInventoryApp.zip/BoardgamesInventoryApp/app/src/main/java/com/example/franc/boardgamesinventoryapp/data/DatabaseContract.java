package com.example.franc.boardgamesinventoryapp.data;

import android.provider.BaseColumns;

/**
 * API Contract for the Boardgame Inventory App.
 */
public class DatabaseContract {

    // To prevent someone from accidentally instantiating the contract class,
    // give it an empty constructor.
    private DatabaseContract() {
    }

    /**
     * Inner class that defines constant values for the games database table.
     * Each entry in the table represents a single pet.
     */
    public static final class GamesEntry implements BaseColumns {

        // Name of database table for games
        public final static String TABLE_NAME = "games";

        //Unique ID number for the game (only for use in the database table), <p>, Type: INTEGER
        public final static String _ID = BaseColumns._ID;

        // Name of the game, Type: TEXT
        public final static String COLUMN_GAME_TITLE = "productName";

        //Gender of the pet. The only possible values are {@link #CATEGORY_PARTY_GAME}, {@link #CATEGORY_AMERICAN},
        // {@link #CATEGORY_GERMAN}, OR {@link #CATEGORY_OTHER}. Type: INTEGER
        public final static String COLUMN_GAME_CATEGORY = "category";

        //Price of the game. Type: INTEGER
        public final static String COLUMN_GAME_PRICE = "price";

        // Quantity of the game. Type: INTEGER
        public final static String COLUMN_GAME_QUANTITY = "quantity";

        // Supplier's name of the game. Type: TEXT
        public final static String COLUMN_GAME_SUPPLIER_NAME = "supplierName";

        // Quantity of the game. Type: INTEGER
        public final static String COLUMN_GAME_SUPPLIER_PHONE_NUMBER = "supplierPhoneNumber";

        // Possible values for the category of the game.
        public static final int CATEGORY_OTHER = 0;
        public static final int CATEGORY_PARTY_GAME = 1;
        public static final int CATEGORY_AMERICAN = 2;
        public static final int CATEGORY_GERMAN = 2;

        // Possible values for the quantity of the game.
        public static final int QUANTITY_ZERO = 0;
        public static final int QUANTITY_ONE = 1;
        public static final int QUANTITY_TWO = 2;
        public static final int QUANTITY_THREE = 3;
        public static final int QUANTITY_FOUR = 4;
        public static final int QUANTITY_FIVE = 5;
        public static final int QUANTITY_SIX = 6;
        public static final int QUANTITY_SEVEN = 7;
        public static final int QUANTITY_EIGHT = 8;
        public static final int QUANTITY_NINE = 9;
        public static final int QUANTITY_TEN = 10;
    }
}

