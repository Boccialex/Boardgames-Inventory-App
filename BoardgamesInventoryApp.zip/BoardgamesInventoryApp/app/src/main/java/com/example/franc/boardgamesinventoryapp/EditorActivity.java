package com.example.franc.boardgamesinventoryapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.franc.boardgamesinventoryapp.data.DatabaseContract.GamesEntry;
import com.example.franc.boardgamesinventoryapp.data.DatabaseHelper;

/**
 * Allows user to create a new pet or edit an existing one.
 */
public class EditorActivity extends AppCompatActivity {

    /** EditText fields to enter games' Title, Price, Supplier's Name, Supplier's Phone Number*/
    private EditText mTitleEditText;
    private EditText mPriceEditText;
    private EditText mSupplierNameEditText;
    private EditText mSupplierContactsEditText;
    private Spinner mCategorySpinner;
    private Spinner mQuantitySpinner;

    /**
     * Category for a game. The possible values are:
     * 0 for other, 1 for party game, 2 for american, 3 for german.
     */
    private int mCategory = GamesEntry.CATEGORY_OTHER;

    /**
     * Quantity for a game. The possible values are:
     * 0 for 0, 1 for one.. And so on until 10.
     */
    private int mQuantity = GamesEntry.QUANTITY_ZERO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        // Find all relevant views that we will need to read user input from

        mTitleEditText = findViewById(R.id.edit_game_name);
        mPriceEditText = findViewById(R.id.edit_price);
        mSupplierNameEditText = findViewById(R.id.edit_supplier_name);
        mSupplierContactsEditText = findViewById(R.id.edit_supplier_phone_number);
        mCategorySpinner = findViewById(R.id.spinner_category);
        mQuantitySpinner = findViewById(R.id.spinner_quantity);

        setupSpinner();
    }

    /**
     * Setup the dropdown spinner that allows the user to select the game's category.
     */
    private void setupSpinner() {
        // Create adapter for spinner. The list options are from the String array it will use
        // the spinner will use the default layout
        ArrayAdapter categorySpinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.array_category_options, android.R.layout.simple_spinner_item);

        // Specify dropdown layout style - simple list view with 1 item per line
        categorySpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        // Apply the adapter to the spinner
        mCategorySpinner.setAdapter(categorySpinnerAdapter);

        // Set the integer mSelected to the constant values
        mCategorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if (!TextUtils.isEmpty(selection)) {
                    if (selection.equals(getString(R.string.category_party_game))) {
                        mCategory = GamesEntry.CATEGORY_PARTY_GAME; // Party Game
                    } else if (selection.equals(getString(R.string.category_american))) {
                        mCategory = GamesEntry.CATEGORY_AMERICAN; // American
                    } else if (selection.equals(getString(R.string.category_german))) {
                        mCategory = GamesEntry.CATEGORY_GERMAN; // German
                    } else {
                        mCategory = GamesEntry.CATEGORY_OTHER; // Other
                    }
                }
            }

            // Because AdapterView is an abstract class, onNothingSelected must be defined
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                mCategory = GamesEntry.CATEGORY_OTHER; // Other
            }
        });

    /**
     * Setup the dropdown spinner that allows the user to select the game's quantity.
     */

        // Create adapter for spinner. The list options are from the String array it will use
        // the spinner will use the default layout
        ArrayAdapter quantitySpinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.array_quantity_options, android.R.layout.simple_spinner_item);

        // Specify dropdown layout style - simple list view with 1 item per line
        quantitySpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        // Apply the adapter to the spinner
        mQuantitySpinner.setAdapter(quantitySpinnerAdapter);

        // Set the integer mSelected to the constant values
        mQuantitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if (!TextUtils.isEmpty(selection)) {
                    if (selection.equals(getString(R.string.quantity_one))) {
                        mQuantity = GamesEntry.QUANTITY_ONE; // One
                    } else if (selection.equals(getString(R.string.quantity_two))) {
                        mQuantity = GamesEntry.QUANTITY_TWO; // Two
                    } else if (selection.equals(getString(R.string.quantity_three))) {
                        mQuantity = GamesEntry.QUANTITY_THREE; // Three
                    } else if (selection.equals(getString(R.string.quantity_four))) {
                        mQuantity = GamesEntry.QUANTITY_FOUR; // Four
                    } else if (selection.equals(getString(R.string.quantity_five))) {
                        mQuantity = GamesEntry.QUANTITY_FIVE; // Five
                    } else if (selection.equals(getString(R.string.quantity_six))) {
                        mQuantity = GamesEntry.QUANTITY_SIX; // Six
                    } else if (selection.equals(getString(R.string.quantity_seven))) {
                        mQuantity = GamesEntry.QUANTITY_SEVEN; // Seven
                    } else if (selection.equals(getString(R.string.quantity_eight))) {
                        mQuantity = GamesEntry.QUANTITY_EIGHT; // Eight
                    } else if (selection.equals(getString(R.string.quantity_nine))) {
                        mQuantity = GamesEntry.QUANTITY_NINE; // Nine
                    } else if (selection.equals(getString(R.string.quantity_ten))) {
                        mQuantity = GamesEntry.QUANTITY_TEN; // Ten
                    } else {
                        mQuantity = GamesEntry.QUANTITY_ZERO; // Zero
                    }
                }
            }

            // Because AdapterView is an abstract class, onNothingSelected must be defined
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                mQuantity = 0; // Zero
            }
        });
    }

    /**
     * Get user input from editor and save game into database.
     */
    private void insertGame() {
        // Read from input fields
        // Use trim to eliminate leading or trailing white space
        String titleString = mTitleEditText.getText().toString().trim();
        String priceString = mPriceEditText.getText().toString().trim();
        String supplierNameString = mSupplierNameEditText.getText().toString().trim();
        String supplierContactsString = mSupplierContactsEditText.getText().toString().trim();
        int price = Integer.parseInt(priceString);

        // Create database helper
        DatabaseHelper mDbHelper = new DatabaseHelper(this);

        // Gets the database in write mode
        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        // Create a ContentValues object where column names are the keys,
        // and game attributes from the editor are the values.
        ContentValues values = new ContentValues();
        values.put(GamesEntry.COLUMN_GAME_TITLE, titleString);
        values.put(GamesEntry.COLUMN_GAME_CATEGORY, mCategory);
        values.put(GamesEntry.COLUMN_GAME_PRICE, priceString);
        values.put(GamesEntry.COLUMN_GAME_QUANTITY, mQuantity);
        values.put(GamesEntry.COLUMN_GAME_SUPPLIER_NAME, supplierNameString);
        values.put(GamesEntry.COLUMN_GAME_SUPPLIER_PHONE_NUMBER, supplierContactsString);

        // Insert a new row for game in the database, returning the ID of that new row.
        long newRowId = db.insert(GamesEntry.TABLE_NAME, null, values);

        // Show a toast message depending on whether or not the insertion was successful
        if (newRowId == -1) {
            // If the row ID is -1, then there was an error with insertion.
            Toast.makeText(this, "Error with saving game", Toast.LENGTH_SHORT).show();
        } else {
            // Otherwise, the insertion was successful and we can display a toast with the row ID.
            Toast.makeText(this, "Game saved with row id: " + newRowId, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/menu_editor.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.action_save:
                // Save game to database
                insertGame();
                // Exit activity
                finish();
                return true;
            // Respond to a click on the "Delete" menu option
            case R.id.action_delete:
                // Do nothing for now
                return true;
            // Respond to a click on the "Up" arrow button in the app bar
            case android.R.id.home:
                // Navigate back to parent activity (CatalogActivity)
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}