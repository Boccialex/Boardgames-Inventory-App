package com.example.franc.boardgamesinventoryapp;

import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

/**
 * Allows user to create a new pet or edit an existing one.
 */
public class EditorActivity extends AppCompatActivity {

    /** EditText fields to enter games' Title, Price, Supplier's Name, Supplier's Phone Number*/
    private EditText mTitleEditText;
    private EditText mPriceEditText;
    private EditText mSupplierNameEditText;
    private EditText mSupplierContactsEditText;
    private Spinner mCategorySpinner;
    private Spinner mQuantitySpinner;

    /**
     * Category for a game. The possible values are:
     * 0 for other, 1 for party game, 2 for american, 3 for german.
     */
    private int mCategory = 0;

    /**
     * Quantity for a game. The possible values are:
     * 0 for 0, 1 for one.. And so on until 10.
     */
    private int mQuantity = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        // Find all relevant views that we will need to read user input from

        mTitleEditText = (EditText) findViewById(R.id.edit_game_name);
        mPriceEditText = (EditText) findViewById(R.id.edit_price);
        mSupplierNameEditText = (EditText) findViewById(R.id.edit_supplier_name);
        mSupplierContactsEditText = (EditText) findViewById(R.id.edit_supplier_phone_number);
        Spinner mCategorySpinner = (Spinner) findViewById(R.id.spinner_category);
        Spinner mQuantitySpinner = (Spinner) findViewById(R.id.spinner_quantity);

        setupSpinner();
    }

    /**
     * Setup the dropdown spinner that allows the user to select the game's category.
     */
    private void setupSpinner() {
        // Create adapter for spinner. The list options are from the String array it will use
        // the spinner will use the default layout
        ArrayAdapter categorySpinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.array_category_options, android.R.layout.simple_spinner_item);

        // Specify dropdown layout style - simple list view with 1 item per line
        categorySpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        // Apply the adapter to the spinner
        mCategorySpinner.setAdapter(categorySpinnerAdapter);

        // Set the integer mSelected to the constant values
        mCategorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if (!TextUtils.isEmpty(selection)) {
                    if (selection.equals(getString(R.string.category_party_game))) {
                        mCategory = 1; // Party Game
                    } else if (selection.equals(getString(R.string.category_american))) {
                        mCategory = 2; // American
                    } else if (selection.equals(getString(R.string.category_german))) {
                        mCategory = 3; // German
                    } else {
                        mCategory = 0; // Other
                    }
                }
            }

            // Because AdapterView is an abstract class, onNothingSelected must be defined
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                mCategory = 0; // Other
            }
        });

    /**
     * Setup the dropdown spinner that allows the user to select the game's quantity.
     */

        // Create adapter for spinner. The list options are from the String array it will use
        // the spinner will use the default layout
        ArrayAdapter quantitySpinnerAdapter = ArrayAdapter.createFromResource(this,
                R.array.array_quantity_options, android.R.layout.simple_spinner_item);

        // Specify dropdown layout style - simple list view with 1 item per line
        quantitySpinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        // Apply the adapter to the spinner
        mQuantitySpinner.setAdapter(quantitySpinnerAdapter);

        // Set the integer mSelected to the constant values
        mQuantitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if (!TextUtils.isEmpty(selection)) {
                    if (selection.equals(getString(R.string.quantity_one))) {
                        mQuantity = 1; // One
                    } else if (selection.equals(getString(R.string.quantity_two))) {
                        mQuantity = 2; // Two
                    } else if (selection.equals(getString(R.string.quantity_three))) {
                        mQuantity = 3; // Three
                    } else if (selection.equals(getString(R.string.quantity_four))) {
                        mQuantity = 4; // Four
                    } else if (selection.equals(getString(R.string.quantity_five))) {
                        mQuantity = 5; // Five
                    } else if (selection.equals(getString(R.string.quantity_six))) {
                        mQuantity = 6; // Six
                    } else if (selection.equals(getString(R.string.quantity_seven))) {
                        mQuantity = 7; // Seven
                    } else if (selection.equals(getString(R.string.quantity_eight))) {
                        mQuantity = 8; // Eight
                    } else if (selection.equals(getString(R.string.quantity_nine))) {
                        mQuantity = 9; // Nine
                    } else if (selection.equals(getString(R.string.quantity_ten))) {
                        mQuantity = 10; // Ten
                    } else {
                        mQuantity = 0; // Zero
                    }
                }
            }

            // Because AdapterView is an abstract class, onNothingSelected must be defined
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                mQuantity = 0; // Zero
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/menu_editor.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.action_save:
                // Do nothing for now
                return true;
            // Respond to a click on the "Delete" menu option
            case R.id.action_delete:
                // Do nothing for now
                return true;
            // Respond to a click on the "Up" arrow button in the app bar
            case android.R.id.home:
                // Navigate back to parent activity (CatalogActivity)
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}